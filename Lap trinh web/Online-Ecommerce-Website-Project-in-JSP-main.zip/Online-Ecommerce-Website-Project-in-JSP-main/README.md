# Online Ecommerce Website Project in JSP
<hr>
<p align="right">Created and designed by AD Singh
<hr>
In this project, I have tried to build an E-commerce website, which can simulate all the basic controls that an actual shopping website has.
<br>
I have used eclipse photon, java 1.8, tomcat 8.5 and MySQL 5.7.31
<br>
<p>Thanx for using <u>Ecommerce Website Project</u></p>

<div align="center"><h3>Preview & Working</h3>
<video width="320" height="240" controls>
  <source src="vid_main.mp4" type="video/mp4">
  Video not supported by your browser(vid_main.mp4) 
</video>
</div>


For more visit <a href="http://projects.adsingh.net/">projects.adsingh.net !</a>

##### If you find any bug in this software, please inform me. I also want to welcome your any suggestion about this web application. Thanks for using this web application.

